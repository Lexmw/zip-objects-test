// Exercise 1: Shop Item Object

const item = {
    name: "Backpack",
    price: 49.99,
    onSale: false,
    originalPrice: 49.99,
    
    sale: function() {
        this.onSale = true;
        this.price = this.price * 0.8;
        console.log(`Item ${this.name} is now on sale for $${this.price.toFixed(2)}`);
    },

    removeSale: function() {
        this.onSale = false;
        this.price = this.originalPrice;
        console.log(`Sale ended. ${this.name} is now $${this.price.toFixed(2)}`);
    }
};

// Example usage
item.sale();
item.removeSale();
