// Exercise 3: Student Constructor

function Student(name, subject, grade) {
    this.name = name;
    this.subject = subject;
    this.grade = grade;

    this.introduce = function() {
        console.log(`Hi, I am ${this.name}, studying ${this.subject} in grade ${this.grade}.`);
    };

    this.finishesSchoolYear = function() {
        if (this.grade < 12) {
            this.grade += 1;
        }
        if (this.grade === 12) {
            console.log(`Congratulations, ${this.name} has graduated!`);
        } else {
            console.log(`${this.name} has moved up to grade ${this.grade}.`);
        }
    };

    this.changeSubject = function(newSubject) {
        this.subject = newSubject;
        console.log(`${this.name} has switched to studying ${this.subject}.`);
    };
}

// Example usage
const student1 = new Student("Alex", "Math", 10);
student1.introduce();
student1.changeSubject("Science");
student1.finishesSchoolYear();
student1.finishesSchoolYear();
student1.finishesSchoolYear();
