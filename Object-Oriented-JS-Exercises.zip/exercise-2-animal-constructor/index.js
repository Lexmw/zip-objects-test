// Exercise 2: Animal Constructor

function Animal(name, sound) {
    this.name = name;
    this.sound = sound;

    this.makeSound = function() {
        console.log(`The ${this.name} says ${this.sound}!`);
    };

    this.describe = function() {
        console.log(`This is a ${this.name}, and it makes the sound '${this.sound}'.`);
    };
}

// Example usage
const dog = new Animal("Dog", "Woof");
dog.makeSound();
dog.describe();
